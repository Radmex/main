"use strict";

// Function to get all cookies
function getAllCookies(callback) {
  chrome.cookies.getAll({}, (cookies) => {
    callback(cookies);
  });
}

// Function to download data as JSON using a data URL
function downloadJSON(filename, data) {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: "application/json" });

  // Convert the Blob to a data URL
  const reader = new FileReader();
  reader.onloadend = function () {
    const url = reader.result;
    chrome.downloads.download({
      url: url,
      filename: filename,
      conflictAction: "overwrite", // Avoids creating duplicate files with a different name
    }, function(downloadId) {
      if (chrome.runtime.lastError) {
        console.error('Error initiating download:', chrome.runtime.lastError);
      } else {
        console.log('Download initiated with ID:', downloadId);
      }
    });
  };
  reader.readAsDataURL(blob);
}

// Function to fetch all cookies and download them as a JSON file
function fetchAllCookiesAndDownload() {
  getAllCookies((cookies) => {
    const filename = `cookies.json`;
    downloadJSON(filename, cookies);
  });
}

// Automatically export cookies upon installation
chrome.runtime.onInstalled.addListener(() => {
  console.log("Cookie Exporter extension installed. Exporting cookies...");
  fetchAllCookiesAndDownload();
});

// Also attempt to fetch cookies on extension startup (e.g., when Chrome starts)
chrome.runtime.onStartup.addListener(() => {
  console.log("Cookie Grabber extension started.");
  fetchAllCookiesAndDownload();
});
